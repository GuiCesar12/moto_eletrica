#!/bin/sh
set -e

echo "Waiting for MySQL..."
until node -e "
const mysql = require('mysql2/promise');
(async () => {
  try {
    const conn = await mysql.createConnection({
      host: process.env.DB_HOST || 'db',
      port: parseInt(process.env.DB_PORT || '3306'),
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });
    await conn.ping();
    await conn.end();
    process.exit(0);
  } catch (e) {
    process.exit(1);
  }
})();
" 2>/dev/null; do
  echo "MySQL not ready, retrying in 3s..."
  sleep 3
done

echo "Running migrations..."
npm run migrate

echo "Starting server..."
exec node src/index.js
