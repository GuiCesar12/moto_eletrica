require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const pool = require('./config/db');

async function migrate() {
  const conn = await pool.getConnection();
  try {
    const schemaPath = path.join(__dirname, '../migrations/001_schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    const statements = schema.split(';').filter((s) => s.trim());
    for (const stmt of statements) {
      await conn.query(stmt);
    }

    const [admins] = await conn.query('SELECT id FROM admin_users LIMIT 1');
    if (admins.length === 0) {
      const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10);
      await conn.query(
        'INSERT INTO admin_users (email, password_hash, name) VALUES (?, ?, ?)',
        [process.env.ADMIN_EMAIL || 'admin@mundoeletrico.com', hash, 'Administrador']
      );
      console.log('Admin user created');
    }

    const [settings] = await conn.query('SELECT id FROM site_settings LIMIT 1');
    if (settings.length === 0) {
      const defaults = [
        ['whatsapp_number', '5521985925203'],
        ['whatsapp_message', 'Olá! Gostaria de saber mais sobre os produtos do Mundo Elétrico.'],
        ['whatsapp_enabled', 'true'],
        ['contact_phone', '(21) 9859-25203'],
        ['contact_email', 'contato@mundoeletricomotors.com.br'],
      ];
      for (const [key, value] of defaults) {
        await conn.query('INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)', [key, value]);
      }
      console.log('Default settings created');
    }

    const [products] = await conn.query('SELECT id FROM products LIMIT 1');
    if (products.length === 0) {
      const seedProducts = [
        ['BIKE ELÉTRICA BOB', 'bike-eletrica-bob', 'Motor: 1000W. Bateria de lítio 60V 20Ah removível. Autonomia: até 55km. Velocidade: até 32km/h.', 'motos', 'Bike', 8999.00, 1000, 32, 55, 'litio', '60V 20Ah removível', 120, 'cbs', false],
        ['BIKE ELÉTRICA DOT', 'bike-eletrica-dot', 'Motor 1000W. Bateria de Lítio 20AH 60 Volts. Autonomia de até 45km.', 'motos', 'Bike', 8499.00, 1000, 32, 45, 'litio', '60V 20Ah', 120, 'cbs', false],
        ['BIKE ELÉTRICA JET', 'bike-eletrica-jet', 'Motor 1000W. Bateria de Lítio 20AH 60 Volts. Autonomia de até 45km podendo variar com as condições.', 'motos', 'Bike', 7999.00, 1000, 32, 45, 'litio', '60V 20Ah', 120, 'cbs', false],
        ['BIKE ELETRICA KRYPTON', 'bike-eletrica-krypton', 'Motor 1000W. Autonomia de até 50km. Velocidade 32km/h. Acabamento premium.', 'motos', 'Bike', 9499.00, 1000, 32, 50, 'litio', '60V 20Ah', 130, 'abs', true],
        ['BIKE ELÉTRICA LUNA', 'bike-eletrica-luna', '350W com pico de 500. Autonomia de até 25km. Velocidade 32km/h. Pintura perolizada. Pulseira NFC.', 'motos', 'Bike', 5999.00, 350, 32, 25, 'litio', '48V 12Ah', 100, 'cbs', true],
        ['BIKE ELÉTRICA ME16', 'bike-eletrica-me16', 'Motor 3000W. Velocidade máxima de até 70km/h. Autonomia de até 35km podendo variar com as condições.', 'motos', 'Bike', 12999.00, 3000, 70, 35, 'litio', '60V 30Ah', 150, 'abs', false],
        ['PATINETE ELÉTRICO X1', 'patinete-eletrico-x1', 'Patinete elétrico compacto. Ideal para mobilidade urbana.', 'motos', 'Patinete', 3499.00, 500, 25, 20, 'litio', '36V 10Ah', 100, 'tambor', false],
        ['BATERIA EXTRA 60V', 'bateria-extra-60v', 'Bateria de lítio 60V 20Ah removível. Compatível com diversos modelos.', 'pecas', 'Autopropelido', 2499.00, 0, 0, 0, 'litio', '60V 20Ah', 0, 'cbs', false],
      ];
      for (const p of seedProducts) {
        await conn.query(
          `INSERT INTO products (name, slug, description, category, vehicle_type, price, motor_power, max_speed, autonomy, battery_type, battery_detail, max_weight, brake_type, has_bluetooth)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          p
        );
      }
      console.log('Seed products created');
    }

    console.log('Migration completed');
  } finally {
    conn.release();
    await pool.end();
  }
}

migrate().catch((err) => {
  console.error('Migration failed:', err);
  process.exit(1);
});
