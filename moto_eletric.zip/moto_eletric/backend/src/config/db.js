require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306'),
  user: process.env.DB_USER || 'moto_user',
  password: process.env.DB_PASSWORD || 'motosecret',
  database: process.env.DB_NAME || 'moto_eletric',
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;
