const pool = require('../config/db');

function slugify(text) {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function buildProductFilters(query, admin = false) {
  const conditions = [];
  const params = [];

  if (!admin) {
    conditions.push('is_active = TRUE');
  }

  if (query.category && query.category !== 'todos') {
    conditions.push('category = ?');
    params.push(query.category);
  }
  if (query.vehicle_type) {
    conditions.push('vehicle_type = ?');
    params.push(query.vehicle_type);
  }
  if (query.autonomy) {
    conditions.push('autonomy >= ?');
    params.push(parseInt(query.autonomy));
  }
  if (query.motor_power) {
    conditions.push('motor_power >= ?');
    params.push(parseInt(query.motor_power));
  }
  if (query.max_speed) {
    conditions.push('max_speed >= ?');
    params.push(parseInt(query.max_speed));
  }
  if (query.max_weight) {
    conditions.push('max_weight >= ?');
    params.push(parseInt(query.max_weight));
  }
  if (query.battery_type) {
    conditions.push('battery_type = ?');
    params.push(query.battery_type);
  }
  if (query.brake_type) {
    conditions.push('brake_type = ?');
    params.push(query.brake_type);
  }
  if (query.has_bluetooth !== undefined && query.has_bluetooth !== '') {
    conditions.push('has_bluetooth = ?');
    params.push(query.has_bluetooth === 'true' || query.has_bluetooth === true);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  let orderBy = 'ORDER BY created_at DESC';
  if (query.sort === 'price_asc') orderBy = 'ORDER BY price ASC';
  if (query.sort === 'price_desc') orderBy = 'ORDER BY price DESC';

  return { where, params, orderBy };
}

async function listProducts(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 6));
    const offset = (page - 1) * limit;

    const { where, params, orderBy } = buildProductFilters(req.query);

    const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM products ${where}`, params);
    const total = countRows[0].total;

    const [products] = await pool.query(
      `SELECT * FROM products ${where} ${orderBy} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    res.json({
      products,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    next(err);
  }
}

async function getProductBySlug(req, res, next) {
  try {
    const [rows] = await pool.query('SELECT * FROM products WHERE slug = ? AND is_active = TRUE', [req.params.slug]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function adminListProducts(req, res, next) {
  try {
    const { where, params, orderBy } = buildProductFilters(req.query, true);
    const [products] = await pool.query(`SELECT * FROM products ${where} ${orderBy}`, params);
    res.json(products);
  } catch (err) {
    next(err);
  }
}

async function createProduct(req, res, next) {
  try {
    const data = req.body;
    const slug = data.slug || slugify(data.name);
    const [result] = await pool.query(
      `INSERT INTO products (name, slug, description, image_url, category, vehicle_type, price, motor_power, max_speed, autonomy, battery_type, battery_detail, max_weight, brake_type, has_bluetooth, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.name,
        slug,
        data.description || '',
        data.image_url || null,
        data.category || 'motos',
        data.vehicle_type || 'Bike',
        parseFloat(data.price) || 0,
        parseInt(data.motor_power) || 0,
        parseInt(data.max_speed) || 0,
        parseInt(data.autonomy) || 0,
        data.battery_type || 'litio',
        data.battery_detail || '',
        parseInt(data.max_weight) || 0,
        data.brake_type || 'cbs',
        data.has_bluetooth === true || data.has_bluetooth === 'true',
        data.is_active !== false && data.is_active !== 'false',
      ]
    );
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'Slug já existe' });
    }
    next(err);
  }
}

async function updateProduct(req, res, next) {
  try {
    const { id } = req.params;
    const data = req.body;
    const [existing] = await pool.query('SELECT id FROM products WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    await pool.query(
      `UPDATE products SET name=?, slug=?, description=?, image_url=?, category=?, vehicle_type=?, price=?, motor_power=?, max_speed=?, autonomy=?, battery_type=?, battery_detail=?, max_weight=?, brake_type=?, has_bluetooth=?, is_active=? WHERE id=?`,
      [
        data.name,
        data.slug || slugify(data.name),
        data.description || '',
        data.image_url || null,
        data.category || 'motos',
        data.vehicle_type || 'Bike',
        parseFloat(data.price) || 0,
        parseInt(data.motor_power) || 0,
        parseInt(data.max_speed) || 0,
        parseInt(data.autonomy) || 0,
        data.battery_type || 'litio',
        data.battery_detail || '',
        parseInt(data.max_weight) || 0,
        data.brake_type || 'cbs',
        data.has_bluetooth === true || data.has_bluetooth === 'true',
        data.is_active !== false && data.is_active !== 'false',
        id,
      ]
    );
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function deleteProduct(req, res, next) {
  try {
    const { id } = req.params;
    const [result] = await pool.query('DELETE FROM products WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    res.json({ message: 'Produto excluído' });
  } catch (err) {
    next(err);
  }
}

async function uploadImage(req, res, next) {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhuma imagem enviada' });
    }
    const imageUrl = `/uploads/${req.file.filename}`;
    await pool.query('UPDATE products SET image_url = ? WHERE id = ?', [imageUrl, req.params.id]);
    res.json({ image_url: imageUrl });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  listProducts,
  getProductBySlug,
  adminListProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  uploadImage,
};
