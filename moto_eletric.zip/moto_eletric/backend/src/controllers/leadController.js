const pool = require('../config/db');

async function createLead(req, res, next) {
  try {
    const { name, email, phone, subject, message } = req.body;
    if (!name || !email || !phone || !subject || !message) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }
    const [result] = await pool.query(
      'INSERT INTO leads (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)',
      [name, email, phone, subject, message]
    );
    res.status(201).json({ id: result.insertId, message: 'Mensagem enviada com sucesso!' });
  } catch (err) {
    next(err);
  }
}

async function listLeads(req, res, next) {
  try {
    let query = 'SELECT * FROM leads';
    const params = [];
    if (req.query.status) {
      query += ' WHERE status = ?';
      params.push(req.query.status);
    }
    query += ' ORDER BY created_at DESC';
    const [leads] = await pool.query(query, params);
    res.json(leads);
  } catch (err) {
    next(err);
  }
}

async function updateLeadStatus(req, res, next) {
  try {
    const { id } = req.params;
    const { status } = req.body;
    if (!['new', 'read', 'contacted'].includes(status)) {
      return res.status(400).json({ error: 'Status inválido' });
    }
    const [result] = await pool.query('UPDATE leads SET status = ? WHERE id = ?', [status, id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Lead não encontrado' });
    }
    const [rows] = await pool.query('SELECT * FROM leads WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function getLeadStats(req, res, next) {
  try {
    const [rows] = await pool.query(
      "SELECT COUNT(*) as total, SUM(status = 'new') as new_count FROM leads"
    );
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { createLead, listLeads, updateLeadStatus, getLeadStats };
