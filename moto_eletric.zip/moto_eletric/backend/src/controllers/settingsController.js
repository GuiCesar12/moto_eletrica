const pool = require('../config/db');

async function getAllSettings() {
  const [rows] = await pool.query('SELECT setting_key, setting_value FROM site_settings');
  const settings = {};
  for (const row of rows) {
    settings[row.setting_key] = row.setting_value;
  }
  return settings;
}

async function getPublicSettings(req, res, next) {
  try {
    const settings = await getAllSettings();
    res.json({
      whatsapp_number: settings.whatsapp_number || '',
      whatsapp_message: settings.whatsapp_message || '',
      whatsapp_enabled: settings.whatsapp_enabled === 'true',
      contact_phone: settings.contact_phone || '',
      contact_email: settings.contact_email || '',
    });
  } catch (err) {
    next(err);
  }
}

async function getAdminSettings(req, res, next) {
  try {
    const settings = await getAllSettings();
    res.json(settings);
  } catch (err) {
    next(err);
  }
}

async function updateSettings(req, res, next) {
  try {
    const allowed = ['whatsapp_number', 'whatsapp_message', 'whatsapp_enabled', 'contact_phone', 'contact_email'];
    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        const value = String(req.body[key]);
        await pool.query(
          'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?',
          [key, value, value]
        );
      }
    }
    const settings = await getAllSettings();
    res.json(settings);
  } catch (err) {
    next(err);
  }
}

module.exports = { getPublicSettings, getAdminSettings, updateSettings };
