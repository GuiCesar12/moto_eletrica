const express = require('express');
const settingsController = require('../controllers/settingsController');
const router = express.Router();

router.get('/public', settingsController.getPublicSettings);

module.exports = router;
