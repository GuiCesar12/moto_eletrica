const express = require('express');
const leadController = require('../controllers/leadController');
const router = express.Router();

router.post('/', leadController.createLead);

module.exports = router;
