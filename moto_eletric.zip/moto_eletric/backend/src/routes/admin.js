const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const auth = require('../middleware/auth');
const productController = require('../controllers/productController');
const leadController = require('../controllers/leadController');
const settingsController = require('../controllers/settingsController');

const router = express.Router();

const uploadDir = path.join(__dirname, '../../uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `product-${req.params.id}-${Date.now()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|gif/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype.split('/')[1]);
    cb(null, ext && mime);
  },
});

router.use(auth);

router.get('/products', productController.adminListProducts);
router.post('/products', productController.createProduct);
router.put('/products/:id', productController.updateProduct);
router.delete('/products/:id', productController.deleteProduct);
router.post('/products/:id/image', upload.single('image'), productController.uploadImage);

router.get('/leads', leadController.listLeads);
router.get('/leads/stats', leadController.getLeadStats);
router.patch('/leads/:id', leadController.updateLeadStatus);

router.get('/settings', settingsController.getAdminSettings);
router.put('/settings', settingsController.updateSettings);

module.exports = router;
