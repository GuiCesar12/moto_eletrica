import { useState, useEffect } from 'react';
import api from '../services/api';
import Header from '../components/Header';
import Hero from '../components/Hero';
import ProductCatalog from '../components/ProductCatalog';
import Locations from '../components/Locations';
import Institutional from '../components/Institutional';
import Media from '../components/Media';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import WhatsAppButton from '../components/WhatsAppButton';

export default function Home() {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    api.getPublicSettings().then(setSettings).catch(console.error);
  }, []);

  return (
    <>
      <Header />
      <Hero />
      <ProductCatalog />
      <Locations />
      <Institutional />
      <Media />
      <Contact settings={settings} />
      <Footer />
      <WhatsAppButton settings={settings} />
    </>
  );
}
