import { useState, useEffect } from 'react';
import api from '../../services/api';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ total: 0, new_count: 0 });
  const [productCount, setProductCount] = useState(0);

  useEffect(() => {
    api.admin.getLeadStats().then(setStats).catch(console.error);
    api.admin.getProducts().then((p) => setProductCount(p.length)).catch(console.error);
  }, []);

  return (
    <div>
      <div className="stats-grid">
        <div className="stat-card">
          <h3>{productCount}</h3>
          <p>Produtos cadastrados</p>
        </div>
        <div className="stat-card">
          <h3>{stats.total || 0}</h3>
          <p>Total de leads</p>
        </div>
        <div className="stat-card">
          <h3>{stats.new_count || 0}</h3>
          <p>Leads novos</p>
        </div>
      </div>
      <div className="admin-card">
        <h3 style={{ marginBottom: 15 }}>Bem-vindo ao painel administrativo</h3>
        <p style={{ color: 'var(--text-light)', fontSize: 14 }}>
          Gerencie produtos, acompanhe leads de contato e configure o botão do WhatsApp.
        </p>
      </div>
    </div>
  );
}
