import { useState, useEffect } from 'react';
import api from '../../services/api';

const STATUS_LABELS = { new: 'Novo', read: 'Lido', contacted: 'Contactado' };

export default function AdminLeads() {
  const [leads, setLeads] = useState([]);
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchLeads = () => {
    setLoading(true);
    api.admin.getLeads(filter || undefined)
      .then(setLeads)
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchLeads(); }, [filter]);

  const updateStatus = async (id, status) => {
    try {
      await api.admin.updateLeadStatus(id, status);
      fetchLeads();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20, alignItems: 'center' }}>
        <h2 style={{ fontSize: 20 }}>Leads</h2>
        <select value={filter} onChange={(e) => setFilter(e.target.value)} style={{ padding: '8px 12px', borderRadius: 4, border: '1px solid var(--border)' }}>
          <option value="">Todos</option>
          <option value="new">Novos</option>
          <option value="read">Lidos</option>
          <option value="contacted">Contactados</option>
        </select>
      </div>
      <div className="admin-card">
        {loading ? (
          <p>Carregando...</p>
        ) : leads.length === 0 ? (
          <p style={{ color: 'var(--text-light)' }}>Nenhum lead encontrado.</p>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Telefone</th>
                <th>Assunto</th>
                <th>Status</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id}>
                  <td>{new Date(lead.created_at).toLocaleDateString('pt-BR')}</td>
                  <td>{lead.name}</td>
                  <td>{lead.email}</td>
                  <td>{lead.phone}</td>
                  <td>
                    <details>
                      <summary>{lead.subject}</summary>
                      <p style={{ fontSize: 12, marginTop: 8, color: 'var(--text-light)' }}>{lead.message}</p>
                    </details>
                  </td>
                  <td>
                    <span className={`status-badge status-${lead.status}`}>
                      {STATUS_LABELS[lead.status]}
                    </span>
                  </td>
                  <td className="admin-actions">
                    {lead.status === 'new' && (
                      <button className="btn-edit btn-sm" onClick={() => updateStatus(lead.id, 'read')}>Marcar lido</button>
                    )}
                    {lead.status !== 'contacted' && (
                      <button className="btn-edit btn-sm" onClick={() => updateStatus(lead.id, 'contacted')}>Contactado</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
