import { useState, useEffect } from 'react';
import api from '../../services/api';

export default function AdminSettings() {
  const [settings, setSettings] = useState({
    whatsapp_number: '',
    whatsapp_message: '',
    whatsapp_enabled: 'true',
    contact_phone: '',
    contact_email: '',
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    api.admin.getSettings().then(setSettings).catch(console.error);
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings({
      ...settings,
      [name]: type === 'checkbox' ? String(checked) : value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);
    try {
      await api.admin.updateSettings(settings);
      setSuccess(true);
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const previewUrl = settings.whatsapp_number
    ? `https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(settings.whatsapp_message || '')}`
    : '';

  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 20 }}>Configurações</h2>
      <div className="admin-card">
        {success && <div className="alert alert-success">Configurações salvas com sucesso!</div>}
        <form onSubmit={handleSubmit}>
          <h3 style={{ marginBottom: 20, color: 'var(--secondary)' }}>WhatsApp</h3>
          <div className="form-group form-check">
            <input
              name="whatsapp_enabled"
              type="checkbox"
              checked={settings.whatsapp_enabled === 'true'}
              onChange={handleChange}
            />
            <label>Botão WhatsApp ativo</label>
          </div>
          <div className="form-group">
            <label>Número (com DDI, ex: 5521985925203)</label>
            <input name="whatsapp_number" value={settings.whatsapp_number || ''} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Mensagem pré-preenchida</label>
            <textarea name="whatsapp_message" value={settings.whatsapp_message || ''} onChange={handleChange} />
          </div>
          {previewUrl && (
            <div className="preview-link">
              <strong>Preview do link:</strong><br />
              <a href={previewUrl} target="_blank" rel="noopener noreferrer">{previewUrl}</a>
            </div>
          )}

          <h3 style={{ margin: '30px 0 20px', color: 'var(--secondary)' }}>Contato</h3>
          <div className="form-row">
            <div className="form-group">
              <label>Telefone</label>
              <input name="contact_phone" value={settings.contact_phone || ''} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>E-mail</label>
              <input name="contact_email" type="email" value={settings.contact_email || ''} onChange={handleChange} />
            </div>
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Salvando...' : 'Salvar Configurações'}
          </button>
        </form>
      </div>
    </div>
  );
}
