import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import '../../styles/admin.css';

export default function AdminLayout() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/admin/login');
  };

  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <h2>Mundo <span>Elétrico</span></h2>
        <nav className="admin-nav">
          <NavLink to="/admin" end>Dashboard</NavLink>
          <NavLink to="/admin/products">Produtos</NavLink>
          <NavLink to="/admin/leads">Leads</NavLink>
          <NavLink to="/admin/settings">Configurações</NavLink>
          <a href="/" target="_blank" rel="noopener noreferrer">Ver Site</a>
          <a href="#" onClick={(e) => { e.preventDefault(); handleLogout(); }}>Sair</a>
        </nav>
      </aside>
      <main className="admin-main">
        <div className="admin-header">
          <h1>Painel Admin</h1>
          <span style={{ color: 'var(--text-light)', fontSize: 14 }}>{user.name || user.email}</span>
        </div>
        <Outlet />
      </main>
    </div>
  );
}
