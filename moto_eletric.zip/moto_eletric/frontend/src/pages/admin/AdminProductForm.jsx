import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../../services/api';

const emptyProduct = {
  name: '',
  slug: '',
  description: '',
  category: 'motos',
  vehicle_type: 'Bike',
  price: 0,
  motor_power: 0,
  max_speed: 0,
  autonomy: 0,
  battery_type: 'litio',
  battery_detail: '',
  max_weight: 120,
  brake_type: 'cbs',
  has_bluetooth: false,
  is_active: true,
};

export default function AdminProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);
  const [product, setProduct] = useState(emptyProduct);
  const [imageFile, setImageFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isEdit) {
      api.admin.getProducts().then((products) => {
        const found = products.find((p) => p.id === parseInt(id));
        if (found) setProduct(found);
      });
    }
  }, [id, isEdit]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setProduct({ ...product, [name]: type === 'checkbox' ? checked : value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      let saved;
      if (isEdit) {
        saved = await api.admin.updateProduct(id, product);
      } else {
        saved = await api.admin.createProduct(product);
      }
      if (imageFile) {
        await api.admin.uploadImage(saved.id, imageFile);
      }
      navigate('/admin/products');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 20 }}>{isEdit ? 'Editar Produto' : 'Novo Produto'}</h2>
      <div className="admin-card">
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label>Nome *</label>
              <input name="name" value={product.name} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Slug</label>
              <input name="slug" value={product.slug || ''} onChange={handleChange} placeholder="auto-gerado se vazio" />
            </div>
          </div>
          <div className="form-group">
            <label>Descrição</label>
            <textarea name="description" value={product.description || ''} onChange={handleChange} />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Categoria</label>
              <select name="category" value={product.category} onChange={handleChange}>
                <option value="motos">MOTOS</option>
                <option value="pecas">PEÇAS</option>
                <option value="outlet">Outlet</option>
              </select>
            </div>
            <div className="form-group">
              <label>Tipo de Veículo</label>
              <select name="vehicle_type" value={product.vehicle_type} onChange={handleChange}>
                <option value="Bike">Bike</option>
                <option value="Patinete">Patinete</option>
                <option value="Ciclomotor">Ciclomotor</option>
                <option value="Autopropelido">Autopropelido</option>
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Preço (R$)</label>
              <input name="price" type="number" step="0.01" value={product.price} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Potência (W)</label>
              <input name="motor_power" type="number" value={product.motor_power} onChange={handleChange} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Velocidade Máx (km/h)</label>
              <input name="max_speed" type="number" value={product.max_speed} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Autonomia (km)</label>
              <input name="autonomy" type="number" value={product.autonomy} onChange={handleChange} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Tipo de Bateria</label>
              <select name="battery_type" value={product.battery_type} onChange={handleChange}>
                <option value="litio">Lítio</option>
                <option value="chumbo">Chumbo</option>
                <option value="niquel">Níquel</option>
              </select>
            </div>
            <div className="form-group">
              <label>Detalhe Bateria</label>
              <input name="battery_detail" value={product.battery_detail || ''} onChange={handleChange} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Peso Suportado (kg)</label>
              <input name="max_weight" type="number" value={product.max_weight} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Freio</label>
              <select name="brake_type" value={product.brake_type} onChange={handleChange}>
                <option value="abs">ABS</option>
                <option value="cbs">CBS</option>
                <option value="tambor">Tambor</option>
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group form-check">
              <input name="has_bluetooth" type="checkbox" checked={product.has_bluetooth} onChange={handleChange} />
              <label>Bluetooth</label>
            </div>
            <div className="form-group form-check">
              <input name="is_active" type="checkbox" checked={product.is_active} onChange={handleChange} />
              <label>Ativo</label>
            </div>
          </div>
          <div className="form-group">
            <label>Imagem</label>
            <input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} />
            {product.image_url && <p style={{ fontSize: 12, marginTop: 5 }}>Atual: {product.image_url}</p>}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Salvando...' : 'Salvar'}
            </button>
            <button type="button" className="btn btn-outline" onClick={() => navigate('/admin/products')}>
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
