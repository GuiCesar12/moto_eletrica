const API_URL = import.meta.env.VITE_API_URL || '/api';

function getToken() {
  return localStorage.getItem('token');
}

async function request(path, options = {}) {
  const headers = { ...options.headers };
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  const token = getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || 'Erro na requisição');
  }
  return data;
}

export const api = {
  login: (email, password) =>
    request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),

  getProducts: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/products?${qs}`);
  },

  getProduct: (slug) => request(`/products/${slug}`),

  createLead: (data) =>
    request('/leads', { method: 'POST', body: JSON.stringify(data) }),

  getPublicSettings: () => request('/settings/public'),

  admin: {
    getProducts: () => request('/admin/products'),
    createProduct: (data) =>
      request('/admin/products', { method: 'POST', body: JSON.stringify(data) }),
    updateProduct: (id, data) =>
      request(`/admin/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    deleteProduct: (id) =>
      request(`/admin/products/${id}`, { method: 'DELETE' }),
    uploadImage: (id, file) => {
      const form = new FormData();
      form.append('image', file);
      return request(`/admin/products/${id}/image`, { method: 'POST', body: form });
    },
    getLeads: (status) => {
      const qs = status ? `?status=${status}` : '';
      return request(`/admin/leads${qs}`);
    },
    getLeadStats: () => request('/admin/leads/stats'),
    updateLeadStatus: (id, status) =>
      request(`/admin/leads/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    getSettings: () => request('/admin/settings'),
    updateSettings: (data) =>
      request('/admin/settings', { method: 'PUT', body: JSON.stringify(data) }),
  },
};

export default api;
