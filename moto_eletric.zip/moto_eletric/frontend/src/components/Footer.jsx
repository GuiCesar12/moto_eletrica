import '../styles/footer.css';

export default function Footer() {
  const scrollTo = (href) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <h4>Mundo Elétrico</h4>
            <p>
              Seu novo conceito para mobilidade urbana. Pioneiros em mobilidade elétrica no Rio de Janeiro e no Brasil.
            </p>
            <div className="social-links">
              <a href="#" aria-label="Facebook">f</a>
              <a href="#" aria-label="Instagram">in</a>
              <a href="#" aria-label="YouTube">▶</a>
            </div>
          </div>
          <div className="footer-col">
            <h4>Links Rápidos</h4>
            <ul className="footer-links">
              <li><a href="#produtos" onClick={(e) => { e.preventDefault(); scrollTo('#produtos'); }}>Nossos Produtos</a></li>
              <li><a href="#onde-estamos" onClick={(e) => { e.preventDefault(); scrollTo('#onde-estamos'); }}>Onde Estamos</a></li>
              <li><a href="#institucional" onClick={(e) => { e.preventDefault(); scrollTo('#institucional'); }}>Missão</a></li>
              <li><a href="#institucional" onClick={(e) => { e.preventDefault(); scrollTo('#institucional'); }}>Visão</a></li>
              <li><a href="#institucional" onClick={(e) => { e.preventDefault(); scrollTo('#institucional'); }}>Valores</a></li>
              <li><a href="#contato" onClick={(e) => { e.preventDefault(); scrollTo('#contato'); }}>Contato</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Contato</h4>
            <div className="footer-contact">
              <p>📞 (21) 9859-25203</p>
              <p>✉️ contato@mundoeletricomotors.com.br</p>
            </div>
          </div>
          <div className="footer-col">
            <h4>Siga-nos</h4>
            <p> Acompanhe nossas novidades e promoções nas redes sociais.</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>By ATC Technology | Copyright © All rights reserved</p>
        </div>
      </div>
    </footer>
  );
}
