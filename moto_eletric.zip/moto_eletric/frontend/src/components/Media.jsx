import { useState } from 'react';
import '../styles/sections.css';

const filters = ['Todos os tipos', 'Eventos', 'Notícias', 'Promoções'];

export default function Media() {
  const [activeFilter, setActiveFilter] = useState('Todos os tipos');

  return (
    <section id="midia" className="section media-section">
      <div className="container">
        <h2 className="section-title">Promoções e informações sobre nossos produtos</h2>
        <div style={{ maxWidth: 400, margin: '0 auto 30px' }}>
          <input
            type="text"
            placeholder="Buscar"
            style={{
              width: '100%',
              padding: '12px 15px',
              border: '1px solid var(--border)',
              borderRadius: 4,
              fontFamily: 'var(--font)',
            }}
          />
        </div>
        <div className="media-filters">
          {filters.map((f) => (
            <button
              key={f}
              className={`media-filter-btn ${activeFilter === f ? 'active' : ''}`}
              onClick={() => setActiveFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="media-empty">
          <h3>Ops! Nenhuma publicação encontrada!</h3>
        </div>
      </div>
    </section>
  );
}
