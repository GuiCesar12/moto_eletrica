import '../styles/sections.css';

const locations = [
  {
    name: 'Loja Centro - Rio de Janeiro',
    address: 'Av. Rio Branco, 123 - Centro',
    city: 'Rio de Janeiro - RJ',
    phone: '(21) 9859-25203',
    hours: 'Seg-Sáb: 9h às 18h',
  },
  {
    name: 'Loja Zona Sul - Rio de Janeiro',
    address: 'Rua Visconde de Pirajá, 456 - Ipanema',
    city: 'Rio de Janeiro - RJ',
    phone: '(21) 9859-25203',
    hours: 'Seg-Sáb: 9h às 18h',
  },
  {
    name: 'Loja Niterói',
    address: 'Rua da Conceição, 789 - Centro',
    city: 'Niterói - RJ',
    phone: '(21) 9859-25203',
    hours: 'Seg-Sáb: 9h às 18h',
  },
];

export default function Locations() {
  return (
    <section id="onde-estamos" className="section">
      <div className="container">
        <h2 className="section-title">Onde Estamos</h2>
        <p style={{ textAlign: 'center', color: 'var(--text-light)', marginBottom: 40 }}>
          Conheça nossos endereços!
        </p>
        <div className="locations-grid">
          {locations.map((loc) => (
            <div key={loc.name} className="location-card">
              <h3>{loc.name}</h3>
              <p>{loc.address}</p>
              <p>{loc.city}</p>
              <p>{loc.phone}</p>
              <p>{loc.hours}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
