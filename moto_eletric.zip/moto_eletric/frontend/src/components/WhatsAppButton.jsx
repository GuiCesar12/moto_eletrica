import { useCompare } from '../context/CompareContext';
import '../styles/whatsapp.css';

export default function WhatsAppButton({ settings }) {
  const { compareList } = useCompare();

  if (!settings?.whatsapp_enabled) return null;

  const number = settings.whatsapp_number || '';
  const message = encodeURIComponent(settings.whatsapp_message || '');
  const url = `https://wa.me/${number}?text=${message}`;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={`whatsapp-btn ${compareList.length > 0 ? 'with-compare-bar' : ''}`}
      aria-label="WhatsApp"
    >
      💬
    </a>
  );
}
