import { useCompare } from '../context/CompareContext';
import '../styles/products.css';

function formatPrice(price) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(price);
}

export default function ProductCard({ product }) {
  const { toggleCompare, isInCompare } = useCompare();
  const inCompare = isInCompare(product.id);

  return (
    <div className="product-card">
      <div className="product-image">
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} />
        ) : (
          <div className="product-image-placeholder">⚡</div>
        )}
      </div>
      <div className="product-body">
        <h3 className="product-name">{product.name}</h3>
        <p className="product-desc">{product.description}</p>
        <div className="product-specs">
          <div className="spec-item">
            <span>🏃</span>
            <strong>{product.max_speed}</strong> km/h
          </div>
          <div className="spec-item">
            <span>⚡</span>
            <strong>{product.motor_power}</strong> W
          </div>
          <div className="spec-item">
            <span>🔋</span>
            <strong>{product.autonomy}</strong> km
          </div>
        </div>
        <div className="product-footer">
          <span className="product-price">{formatPrice(product.price)}</span>
          <button
            className={`compare-btn ${inCompare ? 'active' : ''}`}
            onClick={() => toggleCompare(product)}
          >
            {inCompare ? '✓ Comparar' : 'Comparar'}
          </button>
        </div>
      </div>
    </div>
  );
}
