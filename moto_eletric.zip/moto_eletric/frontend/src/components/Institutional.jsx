import '../styles/sections.css';

const values = [
  {
    title: 'Propósito',
    text: 'Revolucionar a forma como as pessoas se movem, tornando a mobilidade elétrica acessível, inteligente e conectada com o futuro.',
  },
  {
    title: 'Missão',
    text: 'Tornar a mobilidade elétrica uma realidade presente para todos.',
  },
  {
    title: 'Visão',
    text: 'Liderar o mercado de mobilidade elétrica com excelência e inovação.',
  },
  {
    title: 'Valores',
    text: 'Excelência, Compromisso e Conexão — entregamos qualidade em cada detalhe, assumimos a responsabilidade de transformar a mobilidade urbana e acreditamos na proximidade como base para relações duradouras.',
  },
];

export default function Institutional() {
  return (
    <section id="institucional" className="section institutional">
      <div className="container">
        <h2 className="section-title">Bem-vindo a Mundo Elétrico Motors</h2>
        <p className="institutional-intro">
          Somos o Mundo Elétrico Motors - Sua melhor opção de mobilidade! Na <strong>Mundo Elétrico Motors</strong>, temos orgulho de ser pioneiros em mobilidade elétrica no Rio de Janeiro e no Brasil. Mais do que vender veículos, nosso compromisso é com você: oferecemos uma consultoria dedicada para que, entre nossas diversas soluções, você encontre a que melhor se adapta à sua rotina.
        </p>
        <h3 style={{ textAlign: 'center', marginBottom: 30, color: 'var(--secondary)' }}>O QUE NOS ORIENTA</h3>
        <div className="values-grid">
          {values.map((v) => (
            <div key={v.title} className="value-card">
              <h3>{v.title}</h3>
              <p>{v.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
