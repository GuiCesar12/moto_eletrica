import { useState } from 'react';
import api from '../services/api';
import '../styles/sections.css';

export default function Contact({ settings }) {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    try {
      await api.createLead(form);
      setStatus({ type: 'success', message: 'Mensagem enviada com sucesso! Entraremos em contato em breve.' });
      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch (err) {
      setStatus({ type: 'error', message: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contato" className="section contact-section">
      <div className="container">
        <h2 className="section-title">Contatos</h2>
        <div className="contact-grid">
          <div className="contact-info">
            <h3>Fale Conosco</h3>
            <div className="contact-info-item">
              <div className="icon">📞</div>
              <span>{settings?.contact_phone || '(21) 9859-25203'}</span>
            </div>
            <div className="contact-info-item">
              <div className="icon">✉️</div>
              <span>{settings?.contact_email || 'contato@mundoeletricomotors.com.br'}</span>
            </div>
            <h3 style={{ marginTop: 30 }}>Um pouco mais</h3>
            <p style={{ color: 'var(--text-light)', fontSize: 14, lineHeight: 1.8 }}>
              No Mundo Elétrico Motors temos a responsabilidade de levar até você uma visão inovadora de mobilidade urbana. Nossa visão é de inovação, qualidade e custo acessível, cobrando um preço justo, além é claro de prestar suporte com qualidade no pós-venda.
            </p>
          </div>

          <form className="contact-form" onSubmit={handleSubmit}>
            <h3>Fale Conosco</h3>
            {status && (
              <div className={`alert alert-${status.type === 'success' ? 'success' : 'error'}`}>
                {status.message}
              </div>
            )}
            <div className="form-group">
              <label>Nome *</label>
              <input name="name" value={form.name} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>E-mail *</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Celular *</label>
              <input name="phone" value={form.phone} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Assunto *</label>
              <input name="subject" value={form.subject} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Mensagem *</label>
              <textarea name="message" value={form.message} onChange={handleChange} required />
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Enviando...' : 'Enviar Mensagem'}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
