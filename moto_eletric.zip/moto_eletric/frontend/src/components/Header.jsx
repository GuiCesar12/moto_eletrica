import { useState } from 'react';
import { useCompare } from '../context/CompareContext';
import '../styles/header.css';

const navItems = [
  { label: 'Home', href: '#home' },
  {
    label: 'Produtos',
    href: '#produtos',
    children: [
      { label: 'Todos', href: '#produtos' },
      { label: 'MOTOS', href: '#produtos' },
      { label: 'PEÇAS', href: '#produtos' },
    ],
  },
  { label: 'Onde Estamos', href: '#onde-estamos' },
  { label: 'Institucional', href: '#institucional' },
  { label: 'Mídia', href: '#midia' },
  { label: 'Contato', href: '#contato' },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { compareList, clearCompare } = useCompare();

  const scrollTo = (href) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <header className="header">
        <div className="container header-inner">
          <a href="#home" className="logo" onClick={(e) => { e.preventDefault(); scrollTo('#home'); }}>
            Mundo <span>Elétrico</span>
          </a>

          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? '✕' : '☰'}
          </button>

          <nav className={`nav ${menuOpen ? 'open' : ''}`}>
            {navItems.map((item) =>
              item.children ? (
                <div key={item.label} className="nav-dropdown">
                  <a
                    href={item.href}
                    className="nav-link"
                    onClick={(e) => { e.preventDefault(); scrollTo(item.href); }}
                  >
                    {item.label} ▾
                  </a>
                  <div className="nav-dropdown-menu">
                    {item.children.map((child) => (
                      <a
                        key={child.label}
                        href={child.href}
                        onClick={(e) => { e.preventDefault(); scrollTo(child.href); }}
                      >
                        {child.label}
                      </a>
                    ))}
                  </div>
                </div>
              ) : (
                <a
                  key={item.label}
                  href={item.href}
                  className="nav-link"
                  onClick={(e) => { e.preventDefault(); scrollTo(item.href); }}
                >
                  {item.label}
                </a>
              )
            )}
          </nav>
        </div>
      </header>

      <div className={`compare-bar ${compareList.length > 0 ? 'visible' : ''}`}>
        <span>{compareList.length} {compareList.length === 1 ? 'item' : 'itens'} para comparar</span>
        <div className="compare-bar-actions">
          <button className="btn btn-outline" style={{ color: 'white', borderColor: 'white' }} onClick={clearCompare}>
            Limpar
          </button>
        </div>
      </div>
    </>
  );
}
