import '../styles/hero.css';

export default function Hero() {
  const scrollToProducts = () => {
    document.querySelector('#produtos')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="hero">
      <div className="hero-content">
        <h1>Mundo Elétrico</h1>
        <p>Seu novo conceito para mobilidade urbana</p>
        <button className="btn btn-primary" onClick={scrollToProducts}>
          Conheça Nossos Produtos ; )
        </button>
      </div>
    </section>
  );
}
