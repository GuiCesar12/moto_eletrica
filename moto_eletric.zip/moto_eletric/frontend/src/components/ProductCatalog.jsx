import { useState, useEffect, useCallback } from 'react';
import api from '../services/api';
import ProductCard from './ProductCard';
import '../styles/products.css';

const CATEGORIES = [
  { key: 'outlet', label: 'Outlet' },
  { key: 'motos', label: 'MOTOS' },
  { key: 'pecas', label: 'PEÇAS' },
  { key: 'todos', label: 'TODOS' },
];

const FILTER_OPTIONS = {
  vehicle_type: ['', 'Bike', 'Patinete', 'Ciclomotor', 'Autopropelido'],
  autonomy: ['', '10', '15', '20', '25', '30', '35', '45', '50', '55', '70'],
  motor_power: ['', '350', '500', '1000', '3000', '8000'],
  max_speed: ['', '25', '32', '35', '70'],
  max_weight: ['', '100', '120', '130', '150', '200'],
  battery_type: ['', 'chumbo', 'litio', 'niquel'],
  brake_type: ['', 'abs', 'cbs', 'tambor'],
  has_bluetooth: ['', 'true', 'false'],
};

const FILTER_LABELS = {
  vehicle_type: 'Veículos',
  autonomy: 'Autonomia',
  motor_power: 'Potência',
  max_speed: 'Velocidade Máxima',
  max_weight: 'Peso Suportado',
  battery_type: 'Bateria',
  brake_type: 'Freio',
  has_bluetooth: 'Bluetooth',
};

export default function ProductCatalog() {
  const [category, setCategory] = useState('motos');
  const [filters, setFilters] = useState({});
  const [sort, setSort] = useState('default');
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ products: [], pagination: {} });
  const [loading, setLoading] = useState(true);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 6, sort, ...filters };
      if (category !== 'todos') params.category = category;
      const result = await api.getProducts(params);
      setData(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [category, filters, sort, page]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setPage(1);
  };

  const handleCategoryChange = (cat) => {
    setCategory(cat);
    setPage(1);
  };

  const { products, pagination } = data;
  const totalPages = pagination.totalPages || 1;

  return (
    <section id="produtos" className="section products-section">
      <div className="container">
        <div className="products-header">
          <h2 className="section-title">MOTOS</h2>
        </div>

        <div className="category-tabs">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              className={`category-tab ${category === cat.key ? 'active' : ''}`}
              onClick={() => handleCategoryChange(cat.key)}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="filters-row">
          <span style={{ fontSize: 13, fontWeight: 500 }}>Filtre por Tipo:</span>
          {Object.entries(FILTER_OPTIONS).map(([key, options]) => (
            <select
              key={key}
              className="filter-select"
              value={filters[key] || ''}
              onChange={(e) => handleFilterChange(key, e.target.value)}
            >
              <option value="">{FILTER_LABELS[key]} (todos)</option>
              {options.filter(Boolean).map((opt) => (
                <option key={opt} value={opt}>
                  {key === 'has_bluetooth' ? (opt === 'true' ? 'Sim' : 'Não') : opt}
                </option>
              ))}
            </select>
          ))}
          <select className="filter-select" value={sort} onChange={(e) => { setSort(e.target.value); setPage(1); }}>
            <option value="default">Ordenação: Padrão</option>
            <option value="price_desc">Maior Preço</option>
            <option value="price_asc">Menor Preço</option>
          </select>
        </div>

        {loading ? (
          <div className="loading">Carregando produtos...</div>
        ) : products.length === 0 ? (
          <div className="no-products">Nenhum produto encontrado com os filtros selecionados.</div>
        ) : (
          <div className="products-grid">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {totalPages > 1 && (
          <div className="pagination">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)}>‹</button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                className={p === page ? 'active' : ''}
                onClick={() => setPage(p)}
              >
                {p}
              </button>
            ))}
            <button disabled={page >= totalPages} onClick={() => setPage(page + 1)}>›</button>
          </div>
        )}
      </div>
    </section>
  );
}
