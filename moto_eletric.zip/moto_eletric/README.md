# Mundo Elétrico — Clone

Réplica do site [mundoeletricomotors.com.br](https://mundoeletricomotors.com.br/) com Node.js, MySQL e React, 100% containerizado com Docker.

## Stack

- **Frontend:** React 18 + Vite, servido por Nginx
- **Backend:** Node.js + Express
- **Banco:** MySQL 8
- **Infra:** Docker Compose

## Pré-requisitos

- [Docker](https://docs.docker.com/get-docker/) e Docker Compose instalados

## Como subir

```bash
# 1. Copiar variáveis de ambiente
cp .env.example .env

# 2. Subir todos os containers
docker compose up --build

# 3. Acessar
# Site:  http://localhost:8080
# Admin: http://localhost:8080/admin
```

## Credenciais padrão (admin)

Configure no arquivo `.env`:

- **E-mail:** valor de `ADMIN_EMAIL` (padrão: `admin@mundoeletrico.com`)
- **Senha:** valor de `ADMIN_PASSWORD` (padrão: `admin123`)

## Comandos úteis

```bash
# Parar containers
docker compose down

# Parar e apagar volumes (reset do banco)
docker compose down -v

# Ver logs
docker compose logs -f

# Rebuild forçado
docker compose up --build --force-recreate
```

## Estrutura

```
moto_eletric/
├── backend/          # API Express + migrations
├── frontend/         # React + Nginx
├── docker-compose.yml
└── .env.example
```

## Funcionalidades

### Site público
- Layout fiel ao site original (Header, Hero, Produtos, Onde Estamos, Institucional, Mídia, Contato, Footer)
- Catálogo com filtros, paginação e comparação local
- Formulário de contato (salva leads no banco)
- Botão WhatsApp configurável

### Painel Admin (`/admin`)
- Login com JWT
- CRUD de produtos com upload de imagem
- Gestão de leads (novo, lido, contactado)
- Configuração do WhatsApp (número, mensagem, ativo/inativo)

## API

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/products` | Lista produtos (filtros + paginação) |
| POST | `/api/leads` | Enviar formulário de contato |
| GET | `/api/settings/public` | Configurações públicas |
| POST | `/api/auth/login` | Login admin |
| CRUD | `/api/admin/*` | Rotas protegidas (JWT) |

## Portas

| Serviço | Porta externa | Porta interna |
|---------|---------------|---------------|
| Frontend (Nginx) | 8080 | 80 |
| Backend (Express) | — (interno) | 3001 |
| MySQL | — (interno) | 3306 |
